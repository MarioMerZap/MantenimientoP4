package org.mps;

public class SelectionOperatorTest {
    
}
